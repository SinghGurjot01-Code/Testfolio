import path from 'node:path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
export default defineConfig({
  base: process.env.BASE_PATH || '/',
  plugins: [react(), tailwindcss()],
  resolve: { alias: { '@': path.resolve(import.meta.dirname, 'src') }, dedupe: ['react', 'react-dom'] },
  build: { outDir: 'dist', emptyOutDir: true },
  server: { port: Number(process.env.PORT || 5000), host: '0.0.0.0', strictPort: true, allowedHosts: true },
  preview: { port: Number(process.env.PORT || 5000), host: '0.0.0.0', allowedHosts: true },
});
