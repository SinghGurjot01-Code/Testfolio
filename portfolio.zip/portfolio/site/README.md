# Gurjotpal Singh Portfolio

Standalone source package for the portfolio website.

## Run locally

Requirements: Node.js 20+ and npm.

```sh
npm install
npm run dev
```

Open the local URL printed by Vite (normally http://localhost:5000).

## Build and preview

```sh
npm run typecheck
npm run build
npm run preview
```

The production build is written to `dist/`. Set `PORT` to choose another port, or `BASE_PATH` when hosting under a URL subpath.

## Contents

- `src/`: React components, portfolio content and styles
- `public/`: favicon and project brand assets
- `index.html`, `vite.config.ts`, `tsconfig.json`: app configuration

No database, secrets, or user uploads are required by this portfolio.
