export type Project = {
  number: string;
  name: string;
  status: string;
  category: string;
  platform: string;
  link: string;
  linkLabel: string;
  description: string;
  overview: string[];
  features: string[];
  process?: string[];
  stack: string[];
  note?: string;
  benchmark?: { value: string; label: string }[];
};

export const profile = {
  name: "Gurjotpal Singh",
  role: "Developer · Builder · Game Dev",
  description:
    "From web apps and AI tools to game experiments, I turn ideas into real, working products.",
  about:
    "I’m Gurjotpal Singh, a developer with a production mindset studying at CT Group of Institutes. I build practical, real-world systems for developers and everyday users. Open to internships, freelance projects and collaborations.",
  principle: "Every project starts with one question: “What problem does this solve?”",
  study: "BCA · CT Group of Institutes, Shahpur Campus",
  focus: "Full-stack · Cloud · Deployment",
  location: "Punjab, India",
  experience: "3+ Years Learning",
  projectCount: "20+ Projects",
  site: "https://gurjotpalsingh.in",
  cv: "https://gurjotpalsingh.in/Gurjotpal_Singh_CV.pdf",
  contacts: [
    {
      label: "Email",
      value: "singhgurjotpal84@gmail.com",
      href: "mailto:singhgurjotpal84@gmail.com",
    },
    {
      label: "GitHub",
      value: "SinghGurjot01-Code",
      href: "https://github.com/SinghGurjot01-Code",
    },
    {
      label: "Instagram",
      value: "@gurjotsenghww",
      href: "https://instagram.com/gurjotsenghww",
    },
    { label: "Dilect", value: "dilect.site", href: "https://dilect.site" },
  ],
};

export const projects: Project[] = [
  {
    number: "001",
    name: "NebulaCore",
    status: "Flagship Project",
    category: "Cloud gaming platform",
    platform: "Web · Android",
    link: "https://nebulacoreweb.vercel.app/",
    linkLabel: "Visit live website",
    description: "Play PC games without a gaming PC.",
    overview: [
      "A cloud gaming platform: book time on a high-performance gaming PC and play on the phone, tablet or laptop you already own.",
      "NebulaCore turns a powerful gaming PC into something you can use by the hour. You book time on a high-performance machine, then play PC games on your phone, tablet or laptop while the heavy lifting happens on the remote PC instead of your own device.",
      "Billing follows play time: you pay only for the time you play, so there’s no gaming rig to buy up front. It’s my flagship project, and it has grown into a full platform with accounts, an Android app and a download page.",
    ],
    features: [
      "Book a high-performance gaming PC by the hour.",
      "Play from a phone, tablet or laptop.",
      "Pay for the time you actually play.",
      "Games run on remote hardware, so the player’s device does not need to.",
      "An Android APK is available; Google Play is listed as coming.",
      "Accounts support Google sign-in or email and password, backed by Supabase.",
    ],
    process: [
      "Book a session on a high-performance gaming PC.",
      "Launch PC games from a phone, tablet or laptop.",
      "Billing follows the time spent playing.",
    ],
    stack: ["Cloud gaming", "Web app", "Supabase", "Google sign-in", "Android APK"],
  },
  {
    number: "002",
    name: "Graf",
    status: "Early Access",
    category: "Developer tool · MCP server",
    platform: "Windows x64",
    link: "https://grafcore.vercel.app/",
    linkLabel: "Visit live website",
    description: "Your codebase. Understood.",
    overview: [
      "A local-first codebase intelligence workspace and MCP server that gives AI coding agents a map of your project.",
      "Graf parses supported source files into a knowledge graph of files, classes, functions and the relationships between them, then serves that structure to AI coding agents over the Model Context Protocol. Agents query the graph instead of rediscovering your project every session.",
      "Everything runs on your machine: indexing and the embedded SQLite graph are local. Graf Desktop is in Early Access for Windows x64, and the core is open source under the MIT license.",
    ],
    benchmark: [
      { value: "−71.1%", label: "Tokens" },
      { value: "−67.6%", label: "Tool calls" },
      { value: "−58.7%", label: "Wall-clock time" },
      { value: "2.4×", label: "Faster completion" },
    ],
    features: [
      "Turns supported project files into structured nodes and relationships.",
      "Connects to compatible AI coding agents through the Model Context Protocol.",
      "Search files, classes and functions and inspect dependency impact.",
      "Retrieves useful context within a configurable token budget.",
      "Stores project decisions and architectural notes as reviewable memory.",
      "Agents can propose changes for human review; nothing is applied automatically.",
    ],
    process: [
      "Install Graf Desktop.",
      "Select or drag in a project folder.",
      "Index the project locally.",
      "Connect an AI coding agent over MCP.",
      "Ask the agent to query structured project context.",
    ],
    stack: [
      "Node.js",
      "MCP (stdio)",
      "SQLite",
      "Local-first",
      "Desktop app",
      "JavaScript",
      "TypeScript",
      "HTML",
      "CSS",
      "Python",
      "Java",
    ],
    note:
      "Benchmark results came from three real-world web apps and nine head-to-head tasks. They describe one documented benchmark, not universal guarantees; very small files can be quicker to read directly.",
  },
  {
    number: "003",
    name: "PSPC5 Plus",
    status: "Open Source",
    category: "Systems research",
    platform: "Windows x64",
    link: "https://github.com/gurjotsenghww/pspc5-plus",
    linkLabel: "View on GitHub",
    description: "Experimental PlayStation 5 emulation research.",
    overview: [
      "Open-source systems research for Windows x64, from an x86-64 execution bridge to a Vulkan renderer.",
      "PSPC5 Plus is experimental, open-source PlayStation 5 emulation research for Windows x64. It brings the hard parts of the problem into one codebase: a native x86-64 execution bridge, RDNA2-to-SPIR-V shader translation, a dynamic Vulkan renderer and a zero-dependency Windows launcher.",
      "It sits at the low-level end of my work, across C++, Zig, OpenGL and Vulkan, with shader translation and performance tooling along the way. It’s research rather than a finished product, and the source is public.",
    ],
    features: [
      "Native x86-64 execution bridge.",
      "Shader translation from RDNA2 to SPIR-V.",
      "Dynamic rendering backend built on Vulkan.",
      "Zero-dependency Windows launcher.",
    ],
    stack: ["Zig 0.16", "C++", "Vulkan", "SPIR-V", "RDNA2", "x86-64"],
    note: "Experimental research project; not presented as a finished emulator.",
  },
  {
    number: "004",
    name: "Music",
    status: "Clone Website",
    category: "Web app · Clone",
    platform: "Web",
    link: "https://music-5911.firebaseapp.com/",
    linkLabel: "Visit live website",
    description: "A music web app, built as a clone.",
    overview: [
      "A clone website: a music web app with a dedicated music interface, hosted on Firebase.",
      "Music is a clone website, built as a practice project to explore what a dedicated music interface takes on the web. It runs as a Firebase-hosted web app.",
      "It’s here as a build exercise rather than a product, and it sits at the end of the list for that reason.",
    ],
    features: [
      "A layout designed around browsing and playing music.",
      "Firebase-hosted web app.",
      "Practice build made to learn from by recreating a familiar kind of product.",
    ],
    stack: ["Music", "Clone", "Web app", "Firebase"],
    note: "Built for learning and practice; not affiliated with or endorsed by any music service.",
  },
  {
    number: "005",
    name: "Dilect",
    status: "Live",
    category: "Deployment platform",
    platform: "Web",
    link: "https://dilect.site",
    linkLabel: "Visit live website",
    description: "Ship websites with zero configuration.",
    overview: [
      "A deployment platform for getting websites and web apps online without setting anything up first.",
      "Dilect is a deployment platform for shipping websites and web apps with zero configuration. It hooks into GitHub for CI/CD, spins up instant previews, and includes SSL, custom domains and an edge network.",
      "The goal is to keep the path from a repository to a live site short, so shipping doesn’t need a DevOps setup behind it.",
    ],
    features: [
      "Ship without writing setup files first.",
      "Builds and deployments run from a GitHub workflow.",
      "Instant previews before changes go live.",
      "Free SSL for every site.",
      "Custom domains.",
      "Delivery through an edge network.",
    ],
    stack: ["React", "CI/CD", "Cloudflare", "Pages"],
  },
  {
    number: "006",
    name: "Ranqlet",
    status: "Live",
    category: "Builder reputation platform",
    platform: "Web",
    link: "https://ranqlet.com",
    linkLabel: "Visit live website",
    description: "Skill over follower counts.",
    overview: [
      "A reputation-first platform where builders earn standing through the work they ship.",
      "Ranqlet is a reputation-first platform for builders. Instead of resumes and follower counts, it measures people by what they make: you submit projects, other builders rate them, and the ratings feed a leaderboard.",
      "The idea is simple. Skill should travel further than audience size, so the people doing real work are the ones who get found.",
    ],
    features: [
      "Standing comes from shipped work, not follower counts.",
      "Builders submit projects for peer ratings.",
      "Ratings feed a seasonal leaderboard.",
      "Strong projects are surfaced to the community.",
    ],
    stack: ["Next.js", "Tailwind", "Firebase", "Vercel"],
  },
  {
    number: "007",
    name: "CT Gate Pass",
    status: "Discontinued",
    category: "Workflow system",
    platform: "Web",
    link: "https://ctgatepass.in",
    linkLabel: "Project record",
    description: "Digital gate passes for CT Group.",
    overview: [
      "A role-based gate-pass workflow where leave requests moved from student to teacher to the guard at the gate.",
      "CT Gate Pass was a digital gate-pass workflow built for CT Group. A student requested leave, a teacher approved it, and a guard verified the QR code at the gate.",
      "Each role had its own flow, backed by a FastAPI service and Supabase, so a gate pass moved from request to verification inside a single system.",
    ],
    features: [
      "Separate flows for students, teachers and guards.",
      "Guards verified passes by scanning QR codes at the gate.",
      "Built for the students, teachers and guards of CT Group.",
    ],
    process: [
      "A student submitted a leave request.",
      "A teacher reviewed and approved the request.",
      "A guard checked the QR code at the gate.",
    ],
    stack: ["FastAPI", "Supabase", "QR verification", "Role-based access"],
    note: "No longer in development or maintained. The page is kept as a project record.",
  },
];

export const labProjects = [
  {
    number: "01",
    name: "Trauna AI",
    status: "Open Source",
    link: "https://github.com/gurjotsenghww/trauna-ai",
    description:
      "A local-first gaming thumbnail generator built around image-generation models, with a Node.js backend and a Python AI layer optimized for consumer GPUs.",
    stack: ["AI / ML", "FLUX.1-schnell", "SDXL Turbo", "RTX 3050"],
  },
  {
    number: "02",
    name: "Ornàment",
    status: "Open Source",
    link: "https://github.com/gurjotsenghww/ornament",
    description:
      "A local-first autonomous AI website engineer that plans, delegates, implements, tests, diagnoses failures, and applies verified fixes instead of blindly regenerating files.",
    stack: ["AI agents", "Qwen", "Playwright", "Local-first"],
  },
  {
    number: "03",
    name: "Systems & Graphics",
    status: "Engineering",
    link: "https://github.com/gurjotsenghww/pspc5-plus",
    description:
      "Low-level systems engineering across C++, Zig, OpenGL, Vulkan, shader translation, and performance tooling.",
    stack: ["C++", "Zig", "OpenGL", "Vulkan"],
  },
];

export const techCategories = [
  {
    name: "Frontend",
    items: ["HTML5", "CSS", "JavaScript", "Next.js", "React", "TypeScript"],
  },
  {
    name: "Backend",
    items: ["Node.js", "Python", "FastAPI", "Flask", "Express"],
  },
  {
    name: "Database & Auth",
    items: ["Firebase", "Supabase", "PostgreSQL"],
  },
  {
    name: "Deploy & Tools",
    items: [
      "GitHub",
      "Vercel",
      "Render",
      "Google Cloud",
      "Cloudflare",
      "Cloudflare Pages",
      "Cloudflare Workers",
      "Netlify",
      "VS Code Ext",
      "JSON",
      "Dilect",
      "MCP",
      "Antigravity",
      "Figma",
      "CMake",
    ],
  },
  { name: "Payments", items: ["Razorpay"] },
  {
    name: "Game Dev",
    items: ["Unreal Engine", "Blender", "C++", "OpenGL", "Zig", "Unity"],
  },
  {
    name: "Mobile & Android",
    items: ["Android", "Gradle", "Capacitor"],
  },
];
