import { type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowDownRight, ArrowLeft, ArrowRight, ArrowUpRight, Check, Copy, ExternalLink, Layers3, MapPin, Menu, X } from 'lucide-react';
import { labProjects, profile, projects, techCategories, type Project } from '@/data/portfolio';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [selectedTech, setSelectedTech] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const base = import.meta.env.BASE_URL;
  const filteredProjects = useMemo(
    () => selectedTech ? projects.filter((project) => project.stack.some((item) => item.toLowerCase() === selectedTech.toLowerCase())) : projects,
    [selectedTech],
  );
  useEffect(() => {
    if (!activeProject) return;
    const previousFocus = document.activeElement as HTMLElement | null;
    const focusDialog = () => document.querySelector<HTMLElement>('[role="dialog"] button');
    const frame = window.requestAnimationFrame(() => focusDialog()?.focus());
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setActiveProject(null);
      if (event.key === 'Tab') {
        const dialog = document.querySelector<HTMLElement>('[role="dialog"]');
        const focusable = dialog?.querySelectorAll<HTMLElement>('a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])');
        if (!focusable?.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { window.cancelAnimationFrame(frame); window.removeEventListener('keydown', onKey); document.body.style.overflow = ''; previousFocus?.focus(); };
  }, [activeProject]);
  async function copyEmail() {
    try {
      await navigator.clipboard.writeText(profile.contacts[0].value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      window.location.href = profile.contacts[0].href;
    }
  }
  const externalProps = { target: '_blank', rel: 'noopener noreferrer' };
  const artStyle = (project: Project) => {
    const colors: Record<string, string> = {
      NebulaCore: 'linear-gradient(135deg,#db5b3a,#f2a64d)',
      Graf: 'linear-gradient(135deg,#31463e,#779787)',
      'PSPC5 Plus': 'linear-gradient(135deg,#363b52,#878ca9)',
      Music: 'linear-gradient(135deg,#d2a76b,#e9d3aa)',
      Dilect: 'linear-gradient(135deg,#21211f,#55534e)',
      Ranqlet: 'linear-gradient(135deg,#cf6244,#edaa83)',
      'CT Gate Pass': 'linear-gradient(135deg,#8d9e90,#c5c9ae)',
    };
    return { background: colors[project.name] ?? '#d9d2c5' };
  };
  const renderProjectMark = (project: Project) => {
    if (project.name === 'Dilect') return <img src={`${base}brand/dilect.png`} alt="Dilect mark" className="h-20 w-20 rounded-2xl object-cover mix-blend-screen" />;
    if (project.name === 'Graf') return <div className="grid h-20 w-20 place-items-center rounded-[28px] border border-white/40 bg-white/15 text-4xl font-semibold text-white">g.</div>;
    if (project.name === 'NebulaCore') return <div className="relative h-24 w-24 rounded-full border border-white/60"><span className="absolute left-1/2 top-1/2 h-[125%] w-[54%] -translate-x-1/2 -translate-y-1/2 rotate-45 rounded-full border border-white/70" /><span className="absolute left-[10%] top-[22%] h-3 w-3 rounded-full bg-[#fff0bc]" /></div>;
    if (project.name === 'PSPC5 Plus') return <div className="relative grid h-20 w-20 place-items-center text-white"><Layers3 size={60} strokeWidth={1.1} /><span className="absolute bottom-1 right-0 font-mono text-xs">64</span></div>;
    if (project.name === 'Music') return <div className="flex h-24 items-end gap-1.5">{[30, 52, 78, 43, 65, 35, 58].map((height, index) => <i key={index} className="w-2 rounded-full bg-[#fff7e6]/90" style={{ height }} />)}</div>;
    if (project.name === 'Ranqlet') return <div className="serif text-7xl italic tracking-tighter text-[#fff5e4]">R</div>;
    return <div className="relative h-20 w-20 rounded-[24px] border border-white/65"><span className="absolute left-1/2 top-1/2 h-8 w-8 -translate-x-1/2 -translate-y-1/2 rotate-45 border border-white/80" /><span className="absolute bottom-2 left-2 h-2 w-2 rounded-full bg-white" /></div>;
  };
  return (
    <main className="portfolio-shell">
      <div className="grain" aria-hidden="true" />
      <header className="topbar">
        <div className="section-wrap flex h-[76px] items-center justify-between">
          <a href="#home" aria-label="Gurjotpal Singh — home" className="flex items-center gap-3" data-testid="link-home">
            <img src={`${base}brand/favicon.svg`} alt="" className="h-10 w-10 rounded-xl" />
            <span className="text-[13px] font-semibold tracking-[-.02em]">Gurjotpal Singh<span className="ml-1 text-[#d65332]">.</span></span>
          </a>
          <nav aria-label="Main navigation" className={`${menuOpen ? 'absolute left-0 right-0 top-[76px] flex flex-col border-b border-[#d8d0c3] bg-[#f3f0e8] px-6 py-5 shadow-lg' : 'hidden'} gap-5 text-[13px] md:static md:flex md:flex-row md:items-center md:border-0 md:bg-transparent md:p-0 md:shadow-none`}>
            <a className="nav-link" href="#work" onClick={() => setMenuOpen(false)}>Selected work</a>
            <a className="nav-link" href="#lab" onClick={() => setMenuOpen(false)}>The lab</a>
            <a className="nav-link" href="#about" onClick={() => setMenuOpen(false)}>About</a>
            <a className="nav-link" href="#contact" onClick={() => setMenuOpen(false)}>Contact</a>
            <a className="pill inline-flex items-center gap-2 px-4 py-2 text-[12px] font-semibold text-[#d65332] hover:bg-[#e7ded1]" href={profile.cv} {...externalProps} data-testid="link-cv-nav">CV <ArrowUpRight size={14} /></a>
          </nav>
          <button aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'} aria-expanded={menuOpen} className="md:hidden" onClick={() => setMenuOpen(!menuOpen)} data-testid="button-mobile-menu">{menuOpen ? <X size={21} /> : <Menu size={21} />}</button>
        </div>
      </header>

      <section id="home" className="relative overflow-hidden pb-24 pt-16 md:pb-32 md:pt-24">
        <div className="section-wrap relative">
          <div className="absolute right-[3%] top-[-25px] hidden h-[400px] w-[250px] rotate-[28deg] md:block"><div className="hero-orbit inset-0" /><div className="hero-orbit inset-[38px_-22px] rotate-[-18deg]" /><div className="absolute right-[2%] top-[50%] h-3 w-3 rounded-full bg-[#df633f]" /></div>
          <div className="relative z-[1] max-w-[850px]">
            <div className="fade-up mono mb-8 flex items-center gap-3 text-[10px] uppercase tracking-[.2em] text-[#756d62]"><span className="h-px w-8 bg-[#d65332]" /> Developer · Builder · Game Dev <span className="hidden sm:inline">/ Punjab, India</span></div>
            <h1 className="hero-title fade-up delay-1 max-w-[900px] text-[clamp(4rem,10.8vw,9.2rem)]">
              Ideas that<br />
              <span className="relative italic text-[#d65332]">leave the page.</span>
            </h1>
            <div className="fade-up delay-2 mt-9 flex flex-col gap-8 md:ml-[26%] md:flex-row md:items-end md:justify-between">
              <p className="max-w-[410px] text-[16px] leading-[1.8] text-[#655e55]">{profile.description} <span className="text-[#302b25]">Practical by nature. Curious by default.</span></p>
              <a href="#work" className="group inline-flex w-fit items-center gap-3 border-b border-[#302b25]/30 pb-2 text-[13px] font-semibold" data-testid="link-explore-work">Explore the work <ArrowDownRight className="transition-transform group-hover:translate-x-1 group-hover:translate-y-1" size={17} /></a>
            </div>
          </div>
          <div className="mt-16 grid max-w-[800px] grid-cols-2 border-t border-[#d6cec1] pt-5 md:ml-[26%] md:grid-cols-3">
            <div><span className="mono block text-[10px] uppercase tracking-[.16em] text-[#8a8174]">Currently</span><span className="mt-2 block text-[13px]">Building useful things</span></div>
            <div className="mt-5 md:mt-0"><span className="mono block text-[10px] uppercase tracking-[.16em] text-[#8a8174]">Based in</span><span className="mt-2 block text-[13px]"><MapPin className="mr-1 inline" size={13} />{profile.location}</span></div>
            <div className="col-span-2 mt-5 md:col-span-1 md:mt-0"><span className="mono block text-[10px] uppercase tracking-[.16em] text-[#8a8174]">Open to</span><span className="mt-2 block text-[13px]">Internships · Freelance · Collaborations</span></div>
          </div>
        </div>
      </section>

      <section id="work" className="bg-[#e9e4d9] py-20 md:py-28">
        <div className="section-wrap">
          <div className="mb-12 flex flex-col justify-between gap-6 md:mb-16 md:flex-row md:items-end">
            <div><p className="mono mb-4 text-[10px] uppercase tracking-[.2em] text-[#d65332]">01 / Selected work</p><h2 className="serif text-5xl tracking-[-.045em] md:text-7xl">Built to be used.</h2></div>
            <p className="max-w-[310px] text-[13px] leading-6 text-[#6d655b]">A growing collection of practical products, deep dives, and things I learned by making.</p>
          </div>
          {selectedTech && <div className="mb-6 flex items-center justify-between rounded-xl bg-[#f6f2e9] px-4 py-3 text-sm"><span>Showing work connected to <strong>{selectedTech}</strong></span><button onClick={() => setSelectedTech(null)} className="inline-flex items-center gap-2 text-[#d65332]" data-testid="button-clear-filter">Clear filter <X size={14} /></button></div>}
          <div className="grid gap-5 md:grid-cols-2">
            {filteredProjects.map((project, index) => (
              <article key={project.number} className={`project-card group overflow-hidden rounded-[3px] border border-[#d7cfc2] bg-[#f5f1e8] ${project.name === 'NebulaCore' ? 'md:col-span-2 md:grid md:grid-cols-[1.08fr_.92fr]' : ''}`} data-testid={`card-project-${project.number}`}>
                <button onClick={() => setActiveProject(project)} className={`project-art relative flex min-h-[210px] w-full items-center justify-center ${project.name === 'NebulaCore' ? 'md:min-h-[340px]' : ''}`} style={artStyle(project)} aria-label={`Explore ${project.name}`} data-testid={`button-project-${project.number}`}>
                  <span className="absolute left-5 top-5 z-[1] mono text-[10px] text-white/80">{project.number} <span className="mx-2">/</span> {project.status}</span>
                  <span className="absolute right-5 top-5 z-[1] grid h-9 w-9 place-items-center rounded-full border border-white/50 text-white opacity-0 transition-all group-hover:opacity-100"><ArrowUpRight size={16} /></span>
                  {renderProjectMark(project)}
                  {project.name === 'NebulaCore' && <span className="absolute bottom-6 left-6 z-[1] hidden mono text-[9px] uppercase tracking-[.18em] text-white/75 md:block">Your screen is the portal</span>}
                </button>
                <div className="flex flex-col justify-between p-6 md:p-7">
                  <div><div className="mono mb-3 text-[10px] uppercase tracking-[.14em] text-[#8b8072]">{project.category} <span className="mx-2">·</span> {project.platform}</div><h3 className="serif text-[34px] leading-none tracking-[-.03em]">{project.name}</h3><p className="mt-4 max-w-[420px] text-[13px] leading-[1.75] text-[#6c645a]">{project.description}</p></div>
                  <div className="mt-7 flex items-end justify-between gap-3"><div className="flex flex-wrap gap-1.5">{project.stack.slice(0, 3).map((item) => <button key={item} onClick={() => { setSelectedTech(item); document.getElementById('work')?.scrollIntoView({ behavior: 'smooth' }); }} className="pill px-2.5 py-1 text-[10px] text-[#6b6258] hover:border-[#d65332] hover:text-[#d65332]" data-testid={`chip-${project.number}-${item.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`}>{item}</button>)}</div><button onClick={() => setActiveProject(project)} className="flex shrink-0 items-center gap-2 text-[12px] font-semibold text-[#d65332]" data-testid={`button-details-${project.number}`}>Details <ArrowRight size={15} /></button></div>
                </div>
              </article>
            ))}
          </div>
          {!filteredProjects.length && <div className="rounded-2xl border border-dashed border-[#bcb2a3] py-14 text-center text-sm text-[#756d62]">No featured projects tagged with {selectedTech} yet. <button onClick={() => setSelectedTech(null)} className="text-[#d65332] underline">Show all work</button></div>}
        </div>
      </section>

      <section id="lab" className="py-20 md:py-28">
        <div className="section-wrap">
          <div className="mb-12 flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div><p className="mono mb-4 text-[10px] uppercase tracking-[.2em] text-[#d65332]">02 / Side quests</p><h2 className="serif text-5xl tracking-[-.045em] md:text-7xl">The lab stays open.</h2></div>
            <p className="max-w-[320px] text-[13px] leading-6 text-[#6d655b]">Experiments are where the next useful idea usually starts.</p>
          </div>
          <div className="divide-y divide-[#d7cfc2] border-y border-[#d7cfc2]">
            {labProjects.map((lab) => <a key={lab.number} href={lab.link} {...externalProps} className="group grid gap-4 py-6 transition-colors hover:bg-[#ebe5da] md:grid-cols-[70px_1fr_1.3fr_auto] md:items-center md:px-4" data-testid={`link-lab-${lab.number}`}>
              <span className="mono text-[11px] text-[#d65332]">{lab.number}</span>
              <span><span className="serif block text-[28px] tracking-[-.03em]">{lab.name}</span><span className="mono text-[9px] uppercase tracking-[.12em] text-[#887e70]">{lab.status}</span></span>
              <span className="text-[12px] leading-6 text-[#71695f]">{lab.description}</span>
              <span className="flex items-center justify-between gap-4"><span className="hidden max-w-[170px] flex-wrap gap-1.5 md:flex">{lab.stack.slice(0,2).map(tag => <span key={tag} className="pill px-2 py-1 text-[9px] text-[#776f64]">{tag}</span>)}</span><ArrowUpRight size={18} className="text-[#d65332] transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" /></span>
            </a>)}
          </div>
        </div>
      </section>

      <section id="approach" className="bg-[#31443c] py-20 text-[#f4f0e6] md:py-28">
        <div className="section-wrap grid gap-12 md:grid-cols-[.9fr_1.1fr] md:gap-20">
          <div><p className="mono mb-5 text-[10px] uppercase tracking-[.2em] text-[#e99873]">03 / How I build</p><h2 className="serif max-w-[460px] text-5xl leading-[.98] tracking-[-.045em] md:text-7xl">Curiosity, then a working thing.</h2></div>
          <div className="pt-3">
            <p className="serif text-[30px] leading-[1.25] text-[#f5efe1] md:text-[38px]">“{profile.principle.replace(/[“”]/g, '')}”</p>
            <div className="mt-10 grid gap-7 border-t border-white/20 pt-6 sm:grid-cols-2">
              <div><span className="mono text-[10px] uppercase tracking-[.16em] text-[#b2b9ad]">01 / Find the friction</span><p className="mt-3 max-w-[260px] text-[13px] leading-6 text-[#d1d5ca]">Start with the real problem, not the feature list. Make the useful path feel obvious.</p></div>
              <div><span className="mono text-[10px] uppercase tracking-[.16em] text-[#b2b9ad]">02 / Make it real</span><p className="mt-3 max-w-[260px] text-[13px] leading-6 text-[#d1d5ca]">Get a working version into the world, then learn from what happens next.</p></div>
            </div>
          </div>
        </div>
      </section>

      <section id="about" className="py-20 md:py-28">
        <div className="section-wrap grid gap-12 md:grid-cols-[.7fr_1.3fr] md:gap-20">
          <div><p className="mono mb-5 text-[10px] uppercase tracking-[.2em] text-[#d65332]">04 / A little context</p><div className="relative mx-auto grid aspect-square max-w-[230px] place-items-center rounded-full border border-[#d5ccbe] md:mx-0"><div className="absolute inset-4 rounded-full border border-dashed border-[#c9beaf]" /><img src={`${base}brand/favicon.svg`} alt="Gurjotpal Singh monogram" className="h-16 w-16 rounded-[18px]" /><span className="mono absolute -bottom-2 bg-[#f3f0e8] px-3 text-[9px] uppercase tracking-[.14em] text-[#8b8174]">Punjab, India</span></div></div>
          <div><h2 className="serif max-w-[730px] text-4xl leading-[1.04] tracking-[-.04em] md:text-6xl">I like ideas best when someone can actually use them.</h2><p className="mt-7 max-w-[650px] text-[15px] leading-[1.9] text-[#6d655b]">{profile.about}</p>
            <div className="mt-10 grid gap-5 border-t border-[#d7cfc2] pt-6 sm:grid-cols-2">
              <div><span className="mono text-[9px] uppercase tracking-[.15em] text-[#928778]">Learning</span><p className="mt-2 text-[13px]">{profile.study}</p></div>
              <div><span className="mono text-[9px] uppercase tracking-[.15em] text-[#928778]">Focus</span><p className="mt-2 text-[13px]">{profile.focus}</p></div>
              <div><span className="mono text-[9px] uppercase tracking-[.15em] text-[#928778]">Practice</span><p className="mt-2 text-[13px]">{profile.experience}</p></div>
              <div><span className="mono text-[9px] uppercase tracking-[.15em] text-[#928778]">Made so far</span><p className="mt-2 text-[13px]">{profile.projectCount}</p></div>
            </div>
          </div>
        </div>
      </section>

      <section id="stack" className="border-y border-[#d7cfc2] bg-[#ebe6dc] py-16 md:py-20">
        <div className="section-wrap">
          <div className="mb-10 flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><p className="mono mb-3 text-[10px] uppercase tracking-[.2em] text-[#d65332]">05 / In the toolbox</p><h2 className="serif text-4xl tracking-[-.04em] md:text-5xl">Tools I reach for.</h2></div><p className="max-w-[300px] text-[12px] leading-5 text-[#7a7166]">Choose a technology to find the projects where it shows up.</p></div>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {techCategories.map((category, index) => <div key={category.name} className={`${index === 3 ? 'lg:col-span-2' : ''}`}><h3 className="mono mb-3 text-[10px] uppercase tracking-[.15em] text-[#8b8072]">{category.name}</h3><div className="flex flex-wrap gap-2">{category.items.map(item => <button key={item} aria-pressed={selectedTech === item} onClick={() => { setSelectedTech(selectedTech === item ? null : item); document.getElementById('work')?.scrollIntoView({ behavior: 'smooth' }); }} className={`tech-chip pill px-3 py-1.5 text-[11px] ${selectedTech === item ? 'border-[#d65332] bg-[#d65332] text-white' : 'border-[#cec5b7] text-[#514b43] hover:border-[#d65332]'}`} data-testid={`button-tech-${item.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`}>{item}</button>)}</div></div>)}
          </div>
        </div>
      </section>

      <section id="contact" className="relative overflow-hidden bg-[#d95c3b] py-20 text-[#fff7eb] md:py-28">
        <div className="section-wrap relative z-[1]">
          <p className="mono mb-5 text-[10px] uppercase tracking-[.2em] text-white/75">06 / Make something useful</p>
          <div className="grid gap-8 md:grid-cols-[1.2fr_.8fr] md:items-end">
            <div><h2 className="serif max-w-[760px] text-[clamp(3.4rem,8vw,7.4rem)] leading-[.86] tracking-[-.06em]">Good work starts with a conversation.</h2><p className="mt-7 max-w-[420px] text-[14px] leading-7 text-white/85">Have an interesting problem, a team looking for an intern, or an idea worth building? I’m listening.</p></div>
            <div className="flex flex-col items-start gap-4 md:items-end">
              <button onClick={copyEmail} className="inline-flex items-center gap-3 border-b border-white/60 pb-2 text-[17px] font-semibold" data-testid="button-copy-email"><span>{copied ? 'Email copied' : profile.contacts[0].value}</span>{copied ? <Check size={18} /> : <Copy size={17} />}</button>
              <a href={profile.cv} {...externalProps} className="inline-flex items-center gap-2 rounded-full bg-[#fff5e8] px-5 py-3 text-[12px] font-semibold text-[#573c30] transition-transform hover:-translate-y-1" data-testid="link-download-cv">View my CV <ArrowUpRight size={15} /></a>
            </div>
          </div>
          <div className="mt-16 flex flex-col justify-between gap-6 border-t border-white/35 pt-6 sm:flex-row sm:items-center">
            <p className="text-[12px] text-white/80">A personal portfolio by Gurjotpal Singh · {profile.location}</p>
            <div className="flex flex-wrap gap-5 text-[12px]">{profile.contacts.filter(contact => contact.label !== 'Email').map(contact => <a key={contact.label} href={contact.href} {...externalProps} className="inline-flex items-center gap-1.5 hover:text-white/70" data-testid={`link-social-${contact.label.toLowerCase()}`}>{contact.label}<ArrowUpRight size={12} /></a>)}</div>
          </div>
        </div>
        <div aria-hidden="true" className="serif absolute -bottom-[110px] -right-3 text-[min(40vw,440px)] leading-none text-white/[.07]">G</div>
      </section>

      {activeProject && <div className="detail-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setActiveProject(null); }}>
        <section role="dialog" aria-modal="true" aria-labelledby="project-dialog-title" className="detail-panel rounded-[4px]">
          <div className="flex items-center justify-between border-b border-[#ded6c9] px-5 py-4"><button onClick={() => setActiveProject(null)} className="inline-flex items-center gap-2 text-[12px] text-[#71695f]" data-testid="button-back-project"><ArrowLeft size={15} /> Back to work</button><button onClick={() => setActiveProject(null)} aria-label="Close project details" className="grid h-9 w-9 place-items-center rounded-full hover:bg-[#e9e2d7]" data-testid="button-close-project"><X size={18} /></button></div>
          <div className="p-6 md:p-10">
            <div className="mono text-[10px] uppercase tracking-[.15em] text-[#d65332]">{activeProject.number} / {activeProject.category} / {activeProject.status}</div>
            <h2 id="project-dialog-title" className="serif mt-3 text-5xl tracking-[-.05em] md:text-7xl">{activeProject.name}</h2>
            <p className="mt-4 text-lg text-[#655d53]">{activeProject.description}</p>
            <div className="my-7 grid gap-4 border-y border-[#ded6c9] py-5 md:grid-cols-[1fr_auto] md:items-center">
              <p className="max-w-[540px] text-[13px] leading-7 text-[#655d53]">{activeProject.overview[0]}</p>
              <a href={activeProject.link} {...externalProps} className="inline-flex w-fit items-center gap-2 rounded-full bg-[#d65332] px-4 py-2.5 text-[12px] font-semibold text-white hover:bg-[#bd4729]" data-testid="link-project-external">{activeProject.linkLabel}<ExternalLink size={14} /></a>
            </div>
            <div className="space-y-5 text-[13px] leading-7 text-[#655d53]">{activeProject.overview.slice(1).map((paragraph, index) => <p key={index}>{paragraph}</p>)}</div>
            {activeProject.benchmark && <div className="my-8 grid grid-cols-2 gap-px border border-[#dcd3c6] bg-[#dcd3c6] sm:grid-cols-4">{activeProject.benchmark.map(item => <div key={item.label} className="bg-[#f7f4ed] p-4"><div className="serif text-3xl text-[#31443c]">{item.value}</div><div className="mt-1 text-[10px] text-[#786f63]">{item.label}</div></div>)}</div>}
            {activeProject.process && <div className="mt-8"><h3 className="mono mb-3 text-[10px] uppercase tracking-[.15em] text-[#d65332]">How it works</h3><ol className="grid gap-2 sm:grid-cols-2">{activeProject.process.map((step, index) => <li key={step} className="flex gap-3 rounded-lg bg-[#eee9df] p-3 text-[12px] leading-5"><span className="mono text-[#d65332]">0{index + 1}</span>{step}</li>)}</ol></div>}
            <div className="mt-8"><h3 className="mono mb-3 text-[10px] uppercase tracking-[.15em] text-[#d65332]">What it does</h3><ul className="grid gap-2 sm:grid-cols-2">{activeProject.features.map(feature => <li key={feature} className="flex gap-2 text-[12px] leading-5 text-[#655d53]"><Check className="mt-0.5 shrink-0 text-[#54705f]" size={15} />{feature}</li>)}</ul></div>
            {activeProject.note && <p className="mt-7 border-l-2 border-[#d65332] bg-[#eee9df] px-4 py-3 text-[11px] leading-5 text-[#71695f]">{activeProject.note}</p>}
            <div className="mt-8 flex flex-wrap gap-2">{activeProject.stack.map(item => <button key={item} onClick={() => { setSelectedTech(item); setActiveProject(null); setTimeout(() => document.getElementById('work')?.scrollIntoView({ behavior: 'smooth' }), 30); }} className="pill px-3 py-1.5 text-[10px] text-[#5e564c] hover:border-[#d65332] hover:text-[#d65332]" data-testid={`dialog-tech-${item.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`}>{item}</button>)}</div>
          </div>
        </section>
      </div>}
      <footer className="bg-[#302b25] px-5 py-4 text-center text-[10px] text-[#c9c0b3]"><span className="mono">Made with curiosity · {new Date().getFullYear()}</span></footer>
    </main>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
